package mockdemo;

import java.time.LocalDate;

public interface IDateFactory {
	
	public LocalDate now();
	

}
